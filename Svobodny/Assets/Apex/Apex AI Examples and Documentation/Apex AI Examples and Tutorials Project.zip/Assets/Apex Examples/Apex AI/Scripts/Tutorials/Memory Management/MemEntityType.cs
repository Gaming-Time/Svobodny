/* Copyright � 2014 Apex Software. All rights reserved. */
#pragma warning disable 1591

namespace Apex.Examples.AI.Tutorial
{
    public enum MemEntityType
    {
        None = 0,
        Drone = 2,
        Marine = 5
    }
}