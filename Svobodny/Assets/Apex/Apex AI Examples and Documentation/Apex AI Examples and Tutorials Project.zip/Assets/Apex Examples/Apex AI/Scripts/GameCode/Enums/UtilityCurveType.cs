﻿#pragma warning disable 1591

namespace Apex.Examples.AI
{
    public enum UtilityCurveType
    {
        Linear,
        ReversedLinear,
        Exponential,
        ReversedExponential,
        Logistic,
        ReversedLogistic,
        Logit,
        ReversedLogit,
        Gaussian,
        ReversedGaussian
    }
}