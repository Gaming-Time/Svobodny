﻿#pragma warning disable 1591

namespace Apex.Examples.AI.Tutorial
{
    public interface ICustomType
    {
    }
}
