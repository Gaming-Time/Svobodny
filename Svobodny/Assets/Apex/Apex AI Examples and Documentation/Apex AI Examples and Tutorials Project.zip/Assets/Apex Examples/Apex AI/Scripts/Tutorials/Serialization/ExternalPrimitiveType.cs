﻿#pragma warning disable 1591

namespace Apex.Examples.AI.Tutorial
{
    public struct ExternalPrimitiveType
    {
        public float value;

        public ExternalPrimitiveType(float val)
        {
            value = val;
        }
    }
}