#pragma warning disable 1591

namespace Apex.Examples.AI
{
    public enum EntityType
    {
        None = 0,
        Player = 1,
        Drone = 2,
        Marine = 5,
        Any = 500,
    }
}